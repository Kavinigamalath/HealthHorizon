function loadData(data)
{
	if(data=="btn1")
	{
		document.getElementById("image").src = "images/apple.jpg";
		document.getElementById("para").innerHTML = "iPhone is a line of smartphones produced by Apple Inc. that use Apple's own iOS mobile operating system. The first-generation iPhone was announced by then-Apple CEO Steve Jobs on January 9, 2007. Since then, Apple has annually released new iPhone models and iOS updates.";
	}
	else if(data== "btn2")
	{
		document.getElementById("image").src = "images/samsung.jpg";
		document.getElementById("para").innerHTML = "iPhone is a line of smartphones produced by Apple Inc. that use Apple's own iOS mobile operating system. The first-generation iPhone was announced by then-Apple CEO Steve Jobs on January 9, 2007. Since then, Apple has annually released new iPhone models and iOS updates.";
	}
	else if(data== "btn3")
	{
		document.getElementById("image").src = "images/nokia.jpg";
		document.getElementById("para").innerHTML = "iPhone is a line of smartphones produced by Apple Inc. that use Apple's own iOS mobile operating system. The first-generation iPhone was announced by then-Apple CEO Steve Jobs on January 9, 2007. Since then, Apple has annually released new iPhone models and iOS updates.";
	}
	else if(data== "btn4")
	{
		document.getElementById("image").src = "images/oppo.jpg";
		document.getElementById("para").innerHTML = "iPhone is a line of smartphones produced by Apple Inc. that use Apple's own iOS mobile operating system. The first-generation iPhone was announced by then-Apple CEO Steve Jobs on January 9, 2007. Since then, Apple has annually released new iPhone models and iOS updates.";
	}
	
}
	
function priceForLoop()
{
	var phone = ["apple = 3000", "samsung = 2000", "nokia = 800", "oppo = 600"];
	
	var x = phone.length;
	var message = "Here phone list <br/>";
	
	for(let i = 0; i < x; i++)
	{
		message += phone[i] + " <br/>";
	}
	document.getElementById("para").innerHTML = message;
}

function priceHigher()
{
	var phone = {apple : 3000, samsung : 2000, nokia : 800, oppo :600};
	
	var x;
	
	var message = " ";
	for(x in phone)
	{
		if(phone[x] > 1000)
		{
			message += x + " " + phone[x] + "<br/>";
		}
		
	}
	document.getElementById("para").innerHTML = message;
}

function priceLower()
{
	var phone = {apple : 3000, samsung : 2000, nokia : 800, oppo :600};
	
	var x;
	
	var message = " ";
	for(x in phone)
	{
		if(phone[x] < 1000)
		{
			message += x + " " + phone[x] + "<br/>";
		}
		
	}
	document.getElementById("para").innerHTML = message;
}



